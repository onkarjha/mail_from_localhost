<?php
$send_to='RECEIVER EmAIL ID';
$subject="SUBJECT OF mAIL";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$msg_text="SUBSCRIBE TECH WITH ONKAR ON YOUTUBE.";
$msg='<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		*{
			margin:0;
			padding: 0;
			box-sizing: border-box;
		}
		.wrapper{
			width:90%;
			margin:auto;
			border-radius: 5px;
			padding: 20px;
			border:1px solid lightgrey;
		}.hi{
			font-size: 20px;
			font-weight: bold;
		}.greet{
			font-size: 17px;

		}h3{
			padding: 10px;
			text-align: center;
			margin-top:10px;
			border-radius: 5px;
			background: #eef1ff;
		}
	</style>
</head>
<body>
<div class="wrapper">
	<p class="hi">Hi Dear,</p>
	<p class="greet">Thanks for showing interest in our service ! We noticed that you wants to signup in our system. The system generated an one time password (OTP) for your signup. Your OTP is given below copy it and paste it on required input field.</p>
	<h3>'.$msg_text.'</h3>
</div>
</body>
</html>';
mail($send_to,$subject,$msg,$headers);
?>