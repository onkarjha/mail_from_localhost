First of all place the php.ini and sendmail.ini file in the location as per described in the video.

CHANGE PHP.INI FILE
Then move to line number 1085 on php.ini file or simply search sendmail_from = email_id in that file and change the email_id to the email id by which you want to send mail.


CHANGE SENDmAIL.INI FILE
Then move to line number 46 on sendmail.ini file or simply search auth_username=email_id in that file and change the email_id to the email id by which you want to send mail.

Then move to line number 47 on sendmail.ini file or simply search auth_password=your_password in that file and change the your_password to the email id  password.

Then move to line number 60 on sendmail.ini file or simply search force_sender=email_id in that file and change the email_id to the email id by which you want to send mail.



=====  THAT'S IT ====
=====  INSTAGRAm:-- onkarjha2003 =====
=====  YOUTUBE:-- TECH WITH ONKAR ===
 SUBSCRIBE US IT'S FREE

